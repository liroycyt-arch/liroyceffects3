//! Moving over from After Effects.
//!
//! * `.ffx` (an AE animation preset) → `.lcpreset`: every effect the preset uses is recognised by
//!   its AE *match name* (`ADBE Gaussian Blur 2`…) and added to the new preset as the matching
//!   LiroycEffects effect with its default settings. Parameter values and keyframes inside the
//!   `.ffx` are not read.
//! * `.aep` (an AE project) → `.lcproj`: the RIFX container is walked to find the compositions
//!   and the names of their layers; the new project has one composition per AE composition
//!   (1920×1080, 10 s, 29.97 fps) holding one placeholder layer per AE layer, in the same order.
//!   Footage, sizes, timing, keyframes and effects of the original are not converted.
//!
//! Both converters tell the user exactly what was and what was not carried over.

use effectcraft_color::Label;
use effectcraft_project::build::{self, Ids};
use effectcraft_project::{Comp, ItemKind, LayerSource, Project, Solid};
use effectcraft_time::{FrameRate, Tick};
use serde_json::{Value, json};

/// AE effect match name → LiroycEffects effect (by display name; the registry resolves it).
const MATCH_NAMES: &[(&str, &str)] = &[
    ("ADBE Gaussian Blur 2", "Gaussian Blur"),
    ("ADBE Gaussian Blur", "Gaussian Blur"),
    ("ADBE Fast Blur", "Fast Box Blur"),
    ("ADBE Motion Blur", "Directional Blur"),
    ("ADBE Radial Blur", "Radial Blur"),
    ("ADBE Sharpen", "Sharpen"),
    ("ADBE Unsharp Mask2", "Unsharp Mask"),
    ("ADBE Glo2", "Glow"),
    ("ADBE Drop Shadow", "Drop Shadow"),
    ("ADBE Fractal Noise", "Fractal Noise"),
    ("ADBE Turbulent Displace", "Turbulent Displace"),
    ("ADBE Twirl", "Twirl"),
    ("ADBE Spherize", "Spherize"),
    ("ADBE Bulge", "Bulge"),
    ("ADBE Ripple", "Ripple"),
    ("ADBE Wave Warp", "Wave Warp"),
    ("ADBE Mirror", "Mirror"),
    ("ADBE Offset", "Offset"),
    ("ADBE Polar Coordinates", "Polar Coordinates"),
    ("ADBE Corner Pin", "Corner Pin"),
    ("ADBE Mosaic", "Mosaic"),
    ("ADBE Posterize", "Posterize"),
    ("ADBE Threshold2", "Threshold"),
    ("ADBE Find Edges", "Find Edges"),
    ("ADBE Emboss", "Emboss"),
    ("ADBE Invert", "Invert"),
    ("ADBE Noise", "Noise"),
    ("ADBE Strobe", "Strobe Light"),
    ("ADBE Tint", "Tint"),
    ("ADBE Tritone", "Tritone"),
    ("ADBE Brightness & Contrast 2", "Brightness & Contrast"),
    ("ADBE HUE SATURATION", "Hue/Saturation"),
    ("ADBE Easy Levels2", "Levels"),
    ("ADBE Exposure2", "Exposure"),
    ("ADBE Black&White", "Black & White"),
    ("ADBE Color Balance 2", "Color Balance"),
    ("ADBE Vibrance", "Vibrance"),
    ("ADBE CurvesCustom", "Curves"),
    ("ADBE Lumetri", "Lumetri Color"),
    ("ADBE Linear Wipe", "Linear Wipe"),
    ("ADBE Radial Wipe", "Radial Wipe"),
    ("ADBE Venetian Blinds", "Venetian Blinds"),
    ("ADBE Block Dissolve", "Block Dissolve"),
    ("ADBE Echo", "Echo"),
    ("ADBE Posterize Time", "Posterize Time"),
    ("ADBE Timewarp", "Timewarp"),
    ("ADBE Lens Flare", "Lens Flare"),
    ("ADBE Lightning", "Lightning"),
    ("ADBE Vegas", "Vegas"),
    ("ADBE Scribble Fill", "Scribble"),
    ("ADBE Stroke", "Stroke"),
    ("ADBE Ramp", "Gradient Ramp"),
    ("ADBE 4ColorGradient", "4-Color Gradient"),
    ("ADBE Checkerboard", "Checkerboard"),
    ("ADBE Grid", "Grid"),
    ("ADBE Ellipse", "Ellipse"),
    ("ADBE Cell Pattern", "Cell Pattern"),
    ("ADBE Camera Lens Blur", "Camera Lens Blur"),
    ("ADBE Channel Blur", "Channel Blur"),
    ("ADBE Color Key", "Color Key"),
    ("ADBE Linear Color Key2", "Linear Color Key"),
    ("ADBE Luma Key", "Luma Key"),
    ("ADBE Spill2", "Spill Suppressor"),
    ("ADBE Roughen Edges", "Roughen Edges"),
    ("ADBE Scatter", "Scatter"),
    ("ADBE Texturize", "Texturize"),
    ("ADBE Cartoon", "Cartoon"),
    ("ADBE Brush Strokes", "Brush Strokes"),
    ("ADBE Tile", "Motion Tile"),
    ("ADBE Optics Compensation", "Optics Compensation"),
    ("ADBE Liquify", "Liquify"),
    ("ADBE MESH WARP", "Mesh Warp"),
    ("ADBE Bezier Warp", "Bezier Warp"),
    ("ADBE Geometry2", "Transform"),
    ("ADBE Basic 3D", "Basic 3D"),
    ("ADBE Color Emboss", "Color Emboss"),
    ("ADBE Photo Filter", "Photo Filter"),
    ("ADBE Channel Mixer", "Channel Mixer"),
    ("ADBE Colorama", "Colorama"),
    ("ADBE Change Color", "Change Color"),
    ("ADBE Leave Color", "Leave Color"),
    ("ADBE Shadow/Highlight", "Shadow/Highlight"),
    ("ADBE Auto Contrast", "Auto Contrast"),
    ("ADBE Auto Color", "Auto Color"),
    ("ADBE Auto Levels", "Auto Levels"),
];

/// Match names that are containers or bookkeeping inside an `.ffx`, not effects.
const NOT_EFFECTS: &[&str] = &["ADBE Effect Parade", "ADBE Effect Built In Params", "ADBE Effect Parade Group", "ADBE Root Vectors Group", "ADBE Transform Group", "ADBE Layer Styles"];

/// One chunk of a RIFX file (the container of `.aep` and `.ffx`).
struct Chunk<'a> {
    kind: [u8; 4],
    list: Option<[u8; 4]>,
    data: &'a [u8],
    children: Vec<Chunk<'a>>,
}

fn parse_chunks(mut d: &[u8], depth: u32) -> Vec<Chunk<'_>> {
    let mut out = Vec::new();
    while d.len() >= 8 {
        let kind = [d[0], d[1], d[2], d[3]];
        let size = u32::from_be_bytes([d[4], d[5], d[6], d[7]]) as usize;
        let end = (8usize.saturating_add(size)).min(d.len());
        let body = &d[8..end];
        let (list, children) = if &kind == b"LIST" && body.len() >= 4 && depth < 48 { (Some([body[0], body[1], body[2], body[3]]), parse_chunks(&body[4..], depth + 1)) } else { (None, Vec::new()) };
        out.push(Chunk { kind, list, data: body, children });
        let advance = 8usize.saturating_add(size).saturating_add(size & 1);
        if advance >= d.len() {
            break;
        }
        d = &d[advance..];
    }
    out
}

fn riff_body(bytes: &[u8]) -> Result<&[u8], String> {
    if bytes.len() < 12 || &bytes[0..4] != b"RIFX" {
        return Err("not an After Effects file (no RIFX header)".into());
    }
    Ok(&bytes[12..])
}

fn text_of(c: &Chunk<'_>) -> String {
    let end = c.data.iter().position(|b| *b == 0).unwrap_or(c.data.len());
    String::from_utf8_lossy(&c.data[..end]).trim().to_string()
}

fn first_text(chunks: &[Chunk<'_>]) -> Option<String> {
    chunks.iter().find(|c| &c.kind == b"Utf8").map(text_of).filter(|s| !s.is_empty())
}

struct AeComp {
    name: String,
    layers: Vec<String>,
}

fn walk_comps(chunks: &[Chunk<'_>], out: &mut Vec<AeComp>) {
    for c in chunks {
        if c.list == Some(*b"Item") {
            let is_comp = c.children.iter().any(|k| &k.kind == b"cdta");
            if is_comp {
                let name = first_text(&c.children).unwrap_or_else(|| format!("Comp {}", out.len() + 1));
                let layers = c.children.iter().filter(|k| k.list == Some(*b"Layr")).map(|l| first_text(&l.children).unwrap_or_else(|| "Layer".into())).take(500).collect();
                out.push(AeComp { name, layers });
                continue;
            }
        }
        walk_comps(&c.children, out);
    }
}

/// What a conversion produced, for the message the user sees.
pub struct Report {
    pub bytes: Vec<u8>,
    pub summary: String,
}

/// `.aep` → `.lcproj`.
pub fn convert_project(bytes: &[u8]) -> Result<Report, String> {
    let tree = parse_chunks(riff_body(bytes)?, 0);
    let mut comps = Vec::new();
    walk_comps(&tree, &mut comps);
    if comps.is_empty() {
        return Err("no compositions were found in this project".into());
    }
    let rate = FrameRate::FPS_29_97;
    let mut p = Project::default();
    let solids = p.add_item("Solids", Label::Yellow, None, ItemKind::Folder);
    let mut layer_count = 0;
    for ae in &comps {
        let mut comp = Comp::new(1920, 1080, rate, rate.snap_nearest(Tick::from_seconds_f64(10.0)));
        for name in &ae.layers {
            let sid = p.add_item(name, Label::Red, Some(solids), ItemKind::Solid(Solid { color: [0.25, 0.25, 0.32], width: 1920, height: 1080, pixel_aspect: 1.0 }));
            let layer = build::layer(&mut p, &comp, name, LayerSource::Solid { item: sid }, (1920, 1080), None);
            comp.layers.push(layer);
            layer_count += 1;
        }
        p.add_item(&ae.name, Label::Aqua, None, ItemKind::Comp(comp.into()));
    }
    Ok(Report { bytes: p.to_json().into_bytes(), summary: format!("{} compositions, {} layers (names and order only)", comps.len(), layer_count) })
}

/// The AE match names (`ADBE …`, not property paths such as `…-0001`) that appear in the file.
fn match_names(bytes: &[u8]) -> Vec<String> {
    let mut found: Vec<String> = Vec::new();
    let mut i = 0;
    while i + 5 <= bytes.len() {
        if &bytes[i..i + 5] == b"ADBE " {
            let mut j = i + 5;
            while j < bytes.len() && matches!(bytes[j], b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b' ' | b'&' | b'_' | b'-' | b'.' | b'/') {
                j += 1;
            }
            let token = String::from_utf8_lossy(&bytes[i..j]).trim().to_string();
            let is_property = token.len() > 5 && token.as_bytes()[token.len() - 5] == b'-' && token[token.len() - 4..].chars().all(|c| c.is_ascii_digit());
            if !is_property && !found.contains(&token) {
                found.push(token);
            }
            i = j.max(i + 1);
        } else {
            i += 1;
        }
    }
    found
}

/// `.ffx` → `.lcpreset`.
pub fn convert_preset(bytes: &[u8], name: &str) -> Result<Report, String> {
    riff_body(bytes)?;
    let names = match_names(bytes);
    let mut project = Project::default();
    let mut next = project.next_id;
    let mut effects: Vec<Value> = Vec::new();
    let (mut converted, mut skipped) = (Vec::new(), Vec::new());
    for token in &names {
        if NOT_EFFECTS.contains(&token.as_str()) {
            continue;
        }
        let Some((_, ours)) = MATCH_NAMES.iter().find(|(m, _)| m == token) else {
            if !MATCH_NAMES.iter().any(|(m, _)| token.starts_with(m)) {
                skipped.push(token.clone());
            }
            continue;
        };
        let Some(spec) = effectcraft_effects::lookup(ours) else {
            skipped.push(token.clone());
            continue;
        };
        if converted.contains(&spec.name) {
            continue;
        }
        let group = effectcraft_effects::instantiate(spec, &mut Ids(&mut next), spec.name, [1920.0, 1080.0]);
        effects.push(serde_json::to_value(&group).unwrap_or_default());
        converted.push(spec.name);
    }
    project.next_id = next;
    if effects.is_empty() {
        return Err(format!("no effect in this preset has a LiroycEffects equivalent{}", if skipped.is_empty() { String::new() } else { format!(" (found: {})", skipped.join(", ")) }));
    }
    let doc = json!({"effectcraftAnimationPreset": 1, "name": name, "properties": [], "effects": effects});
    let mut summary = format!("{} effects: {}", converted.len(), converted.join(", "));
    if !skipped.is_empty() {
        summary.push_str(&format!(" · no equivalent: {}", skipped.join(", ")));
    }
    Ok(Report { bytes: serde_json::to_string_pretty(&doc).unwrap_or_default().into_bytes(), summary })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn riff(children: &[u8]) -> Vec<u8> {
        let mut v = b"RIFX".to_vec();
        v.extend_from_slice(&((children.len() + 4) as u32).to_be_bytes());
        v.extend_from_slice(b"Egg!");
        v.extend_from_slice(children);
        v
    }

    #[test]
    fn rejects_other_files() {
        assert!(convert_project(b"hello").is_err());
        assert!(convert_preset(b"hello", "x").is_err());
    }

    #[test]
    fn finds_effect_match_names_but_not_property_paths() {
        let mut body = Vec::new();
        body.extend_from_slice(b"junk\0ADBE Gaussian Blur 2\0ADBE Gaussian Blur 2-0001\0ADBE Effect Parade\0");
        let names = match_names(&riff(&body));
        assert!(names.contains(&"ADBE Gaussian Blur 2".to_string()));
        assert!(!names.iter().any(|n| n.ends_with("-0001")));
    }
}
