//! File ▸ Convert After Effects Preset / Project (also the Home ▸ "Migrate from AE" page).

use serde_json::{Value, json};

use super::{CommandSpec, always, bad, str_p};
use crate::{EngineError, Event, Result, Session, cmd};

fn out_path(input: &str, ext: &str) -> String {
    std::path::Path::new(input).with_extension(ext).to_string_lossy().to_string()
}

fn convert(s: &mut Session, p: &Value, id: &str, ext: &str, run: fn(&[u8], &str) -> std::result::Result<crate::ae_migrate::Report, String>) -> Result<Value> {
    let path = str_p(p, "path").ok_or_else(|| bad(id, "missing `path`"))?.to_string();
    let bytes = s.services.read_file(&path).map_err(|e| EngineError::Other(format!("cannot read {path}: {e}")))?;
    let name = std::path::Path::new(&path).file_stem().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
    match run(&bytes, &name) {
        Ok(report) => {
            let out = str_p(p, "out").map(str::to_string).unwrap_or_else(|| out_path(&path, ext));
            s.services.write_file(&out, &report.bytes).map_err(|e| EngineError::Other(format!("cannot write {out}: {e}")))?;
            s.events.push(Event::Toast { message: format!("Converted to {out}: {}", report.summary), error: false });
            Ok(json!({"path": out, "summary": report.summary}))
        }
        Err(e) => {
            s.events.push(Event::Toast { message: format!("Conversion failed: {e}"), error: true });
            Err(bad(id, e))
        }
    }
}

pub fn specs() -> Vec<CommandSpec> {
    vec![
        cmd!("ae.convertPreset", "Convert After Effects Preset (.ffx)...", ["File"], None, "{path (.ffx), out?} → writes a .lcpreset next to it", always, |s, p| convert(s, p, "ae.convertPreset", "lcpreset", |b, n| crate::ae_migrate::convert_preset(b, n))),
        cmd!("ae.convertProject", "Convert After Effects Project (.aep)...", ["File"], None, "{path (.aep), out?} → writes a .lcproj next to it", always, |s, p| convert(s, p, "ae.convertProject", "lcproj", |b, _| crate::ae_migrate::convert_project(b))),
    ]
}
