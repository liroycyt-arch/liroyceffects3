//! LiroycEffects has no online links: no website, no community server, no repository.

pub const APP_NAME: &str = "LiroycEffects";
pub const APP_SLUG: &str = "effectcraft";
